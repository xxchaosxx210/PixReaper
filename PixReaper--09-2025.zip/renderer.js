// renderer.js
// Handles UI interactions and IPC for PixReaper

// --- Webview Controls ---
const webview = document.getElementById("browserView");
const urlInput = document.getElementById("urlInput");
const goButton = document.getElementById("goBtn");
const scanButton = document.getElementById("scanBtn");

goButton.addEventListener("click", () => {
    let url = urlInput.value.trim();
    if (!/^https?:\/\//i.test(url)) {
        url = "https://" + url;
    }
    webview.loadURL(url);
});

// Update address bar when webview navigates
webview.addEventListener("did-navigate", (event) => {
    urlInput.value = event.url;
});

// Request scan of current webview page
scanButton.addEventListener("click", () => {
    webview.executeJavaScript(`
    Array.from(document.querySelectorAll('a'))
      .map(a => a.href)
      .filter(h => !!h);
  `).then((links) => {
        console.log("[Renderer] Sending links to main:", links.length);
        window.electronAPI.send("scan-page", links);
    });
});

// --- Results List ---
const resultsList = document.getElementById("results");

window.electronAPI.receive("scan-progress", (_event, data) => {
    const li = document.createElement("li");
    li.className = data.status;
    li.innerHTML = `
    <span class="status-icon ${data.status}"></span>
    <a href="${data.resolved || data.original}" target="_blank">
      ${data.resolved || data.original}
    </a>
  `;
    resultsList.appendChild(li);
});

// --- Options Modal Logic ---
const optionsModal = document.getElementById("optionsModal");
const optionsButton = document.getElementById("optionsBtn");
const cancelOptions = document.getElementById("cancelOptions");
const saveOptions = document.getElementById("saveOptions");
const maxConnections = document.getElementById("maxConnections");
const maxConnectionsValue = document.getElementById("maxConnectionsValue");

// Open modal
optionsButton.addEventListener("click", () => {
    optionsModal.style.display = "block";
});

// Close modal without saving
cancelOptions.addEventListener("click", () => {
    optionsModal.style.display = "none";
});

// Slider live update
maxConnections.addEventListener("input", () => {
    maxConnectionsValue.textContent = maxConnections.value;
});

// Save options
saveOptions.addEventListener("click", () => {
    const newOptions = {
        prefix: document.getElementById("prefix").value.trim(),
        savePath: document.getElementById("savePath").value.trim(),
        createSubfolder: document.getElementById("subfolder").checked,
        maxConnections: parseInt(document.getElementById("maxConnections").value, 10)
    };

    console.log("[Renderer] Saving options:", newOptions);
    window.electronAPI.send("options:save", newOptions);

    optionsModal.style.display = "none"; // close modal after save
});

// --- IPC: Options Load/Save ---

// Fill modal fields when options are loaded
window.electronAPI.receive("options:load", (_event, opt) => {
    console.log("[Renderer] Loaded options:", opt);

    document.getElementById("prefix").value = opt.prefix ?? "";
    document.getElementById("savePath").value = opt.savePath ?? "";
    document.getElementById("subfolder").checked = !!opt.createSubfolder;

    const slider = document.getElementById("maxConnections");
    slider.value = opt.maxConnections ?? 10;
    const label = document.getElementById("maxConnectionsValue");
    if (label) label.textContent = slider.value;
});

// Confirm when options are saved
window.electronAPI.receive("options:saved", (_event, saved) => {
    console.log("[Renderer] Options saved:", saved);
    // Optional: add a notice in the modal here
});
